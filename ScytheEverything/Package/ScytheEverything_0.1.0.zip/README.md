# Scythe Everything

Makes the Scythe a little more, um, versatile.

## It's kinda stupid

Yeah, it is, but it's also kinda fun.

