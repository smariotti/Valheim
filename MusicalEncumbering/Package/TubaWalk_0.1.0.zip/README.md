# Tuba Walk

Moving while encumbered now has the soundtrack that it deserves.

## It's kinda stupid

Yeah, it is, but it's also kinda fun.

