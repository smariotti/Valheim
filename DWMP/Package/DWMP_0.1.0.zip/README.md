# Dude, Where's My Portal

This is a simple Valheim mod for BepInEx which automatically manages Minimap Pins for portals based on what you do with portals in the game world.

## Place a Portal

When you place a Wooden or Stone portal in Valheim, a Minimap Pin will automatically be added.

## Remove a Portal

When you destroy a portal or it gets destroyed by something else, it'll be removed from the Minimap

## Rename a Portal

When you rename a portal, it'll automatically be renamed in the Minimap

## That's it.

That's really all this thing does.
