# InstaSmelt

This is a simple Valheim mod for BepInEx which automatically smelts ores into bars when they enter your inventory.

It was taken from TrophyHuntMod's Saga game modes where ores Insta-Smelt when picked up out of chests or off the ground.

## Just interact with Ores

They turn into smelted metal.

## That's it.

That's really all this thing does.

## Change Log
v0.1.0
- Initial version